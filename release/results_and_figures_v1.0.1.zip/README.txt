Result tables and figures for the thirteen-dataset HTE audit (v1.0.1)
=====================================================================

Contents
  results/       29 CSV tables, exactly as produced by run_all.bat
  figures/       13 PNG panels at the resolution used in the manuscript

How this was produced
  run_all.bat on the released code, Python 3.10, the pinned requirements.
  The two panels fig3a_shares.png and fig8a_acquisition.png carry their
  '(a)' label added by stamp_missing_labels.py after the run; nothing else
  was edited.

How to check it
  1. fetch_datasets.bat && run_all.bat
  2. compare your results/ with results/ in this archive: the tables are
     deterministic except graph_baseline.csv, whose three GNN rows carry a
     training seed spread of 0.022 / 0.013 / 0.006 R2.

Every file's SHA-256 is listed in MANIFEST.sha256.
Archived under the concept DOI 10.5281/zenodo.23772914.
